package com.unitymedved.installreferrer;

public interface InstallReferrerCallback {
    void Success(InstallReferrerData data);
    void Error(String message);
}