package com.unitymedved.installreferrer;

public class InstallReferrerData {
    public String referrer;
    public String version;
    public boolean googlePlayInstant;
    public long installBeginTimestampSeconds;
    public long installBeginTimestampServerSeconds;
    public long referrerClickTimestampSeconds;
    public long referrerClickTimestampServerSeconds;

    public InstallReferrerData(String Referrer, String Version, Boolean GooglePlayInstant,
                               long InstallBeginTimestampSeconds, long InstallBeginTimestampServerSeconds,
                               long ReferrerClickTimestampSeconds, long ReferrerClickTimestampServerSeconds) {
        referrer = Referrer;
        version = Version;
        googlePlayInstant = GooglePlayInstant;
        installBeginTimestampSeconds = InstallBeginTimestampSeconds;
        installBeginTimestampServerSeconds = InstallBeginTimestampServerSeconds;
        referrerClickTimestampSeconds = ReferrerClickTimestampSeconds;
        referrerClickTimestampServerSeconds = ReferrerClickTimestampServerSeconds;
    }
}
