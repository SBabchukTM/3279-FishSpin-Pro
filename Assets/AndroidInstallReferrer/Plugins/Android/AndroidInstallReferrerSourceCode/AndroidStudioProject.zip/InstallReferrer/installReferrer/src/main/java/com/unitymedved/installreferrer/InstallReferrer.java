package com.unitymedved.installreferrer;

import android.content.Context;

import com.android.installreferrer.api.InstallReferrerClient;
import com.android.installreferrer.api.InstallReferrerStateListener;
import com.android.installreferrer.api.ReferrerDetails;

public class InstallReferrer {
    public void GetInstallReferrerData(Context appContext, final InstallReferrerCallback callback) {
        final InstallReferrerClient referrerClient = InstallReferrerClient.newBuilder(appContext).build();
        referrerClient.startConnection(new InstallReferrerStateListener() {

            public void onInstallReferrerSetupFinished(int responseCode) {
                switch (responseCode) {
                    case InstallReferrerClient.InstallReferrerResponse.OK:
                        try {
                            ReferrerDetails referrer = referrerClient.getInstallReferrer();
                            InstallReferrerData data = new InstallReferrerData(
                                    referrer.getInstallReferrer(), referrer.getInstallVersion(), referrer.getGooglePlayInstantParam(),
                                    referrer.getInstallBeginTimestampSeconds(), referrer.getInstallBeginTimestampServerSeconds(),
                                    referrer.getReferrerClickTimestampSeconds(), referrer.getReferrerClickTimestampServerSeconds());
                            callback.Success(data);
                        } catch (Exception e) {
                            callback.Error(e.toString());
                        }
                        break;
                    case InstallReferrerClient.InstallReferrerResponse.SERVICE_DISCONNECTED:
                        callback.Error("SERVICE_DISCONNECTED");
                        break;
                    case InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE:
                        callback.Error("SERVICE_UNAVAILABLE");
                        break;
                    case InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED:
                        callback.Error("FEATURE_NOT_SUPPORTED");
                        break;
                    case InstallReferrerClient.InstallReferrerResponse.DEVELOPER_ERROR:
                        callback.Error("DEVELOPER_ERROR");
                        break;
                }
                try {
                    referrerClient.endConnection();
                }
                catch (Exception exception) { }
            }

            public void onInstallReferrerServiceDisconnected() { }
        });
    }
}